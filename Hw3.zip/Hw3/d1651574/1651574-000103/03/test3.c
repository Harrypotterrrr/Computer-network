//test3.c
#include <stdio.h>
int main()
{
	printf("1651574\n");
	printf("�����\n");
	return 0;
}
//test3.c
#include "test.h"
int main()
{
	fun1();
	fun2();
	return 0;
}
//test.h
#include <stdio.h>
#define a 10
int fun1();
int fun2();

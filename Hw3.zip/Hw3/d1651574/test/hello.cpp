#include "hello.h"
void hello(){
    cout<<"Hello World!"<<endl;
}

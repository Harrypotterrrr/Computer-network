#include <iostream>  
#include "hello.h"
int main(){  
    cout<<"call function"<<endl;
    hello();  
}